#!/usr/bin/python
"""
Purpose: Defining Tuples
"""
# With single elements
values = [1]
print(type(values), values)

values = (1)
print(type(values), values)

values = (1,)
print(type(values), values)

print()
# EMpty
values = list()  #[]
print(type(values), values)
values = tuple() # ()
print(type(values), values)

assert list() == []
assert tuple() == ()

print(dir(values))

assert values.__len__() == len(values)

