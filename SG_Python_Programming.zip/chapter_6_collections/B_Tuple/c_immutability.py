#!/usr/bin/python
"""
Purpose: Immutability of tuples
"""
mytuple = (11, 22, 33)
print('mytuple[2]', mytuple[2])

# mytuple[2] = 'two' # TypeError: 'tuple' object does not support item assignment

# NOTE: Tuples are immutable


# Overwriting an object
print('before overwriting', id(mytuple))
mytuple = (11, 22, 'three')
print('after overwriting', id(mytuple))
print(mytuple)

