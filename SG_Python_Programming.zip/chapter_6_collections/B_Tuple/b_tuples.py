#!/usr/bin/python
"""
Purpose: Tuple Operations
"""
mytuple = (1, 2, 3)

# Tuple repetition
print('mytuple * 2', mytuple * 2)

# mytuple + 12  # TypeError: can only concatenate tuple (not "int") to tuple
# mytuple + (12)  # TypeError: can only concatenate tuple (not "int") to tuple
assert mytuple + (12,) == (1, 2, 3, 12)

assert mytuple.__str__() == str(mytuple)

print(dir(mytuple))
for ech_attr in dir(mytuple):
    if not ech_attr.startswith('__'):
        print(ech_attr)

newtuple = (11, 22, 22, 34, 11, (22))
print('newtuple.count(22)', newtuple.count(22))  # 3

newtuple = (11, 22, 22, 34, 11, (22,))
print('newtuple.count(22)', newtuple.count(22))  # 2

print('newtuple.index(22)', newtuple.index(22))
print('newtuple.index(22, 2)', newtuple.index(22, 2)) # start_index = 2