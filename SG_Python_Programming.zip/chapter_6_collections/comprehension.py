#!/usr/bin/python
"""
Purpose: Comprehensions
"""

new_list = []
for i in [1, 2, 3, 4, 5]:
    new_list.append(i)
print(new_list)

print([i for i in [1, 2, 3, 4, 5]])

##############################
new_list = []
for i in range(9):
    new_list.append(i)
print(new_list)

print([i for i in range(9)])

#################################
new_list = []
for i in range(20):
    if i % 2 == 0:
        new_list.append(i)
print(new_list)

print([i for i in range(20) if i % 2 == 0])

###################
new_set = set()
for i in range(20):
    for j in range(i):
        if i % 2 == 0 and j % 2 == 0:
            new_set.add(i)
print(new_set)

print({i for i in range(20) for j in range(i) if i % 2 == 0 and j % 2 == 0})
print((i for i in range(20) for j in range(i) if i % 2 == 0 and j % 2 == 0))

##############################
# Ternary operator in python

print('greater' if 12 > 3 else 'lower')

print('divisble by three' if 12 % 3 == 0 else 'not divisible')
########################
new_dict = dict()
for i in range(20):
    if i % 2 == 0:
        new_dict[i] = 'even'
    else:
        new_dict[i] = 'odd'
print(new_dict)
from pprint import pprint

pprint(new_dict)

print(['even' if i % 2 == 0 else 'odd' for i in range(20)])
print({ i:('even' if i % 2 == 0 else 'odd') for i in range(20)})
