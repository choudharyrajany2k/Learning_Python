#!/usr/bin/python
"""
Purpose: Dictionary Operations
"""
mydict = {'one': 1, 'two': 22, 'three': 333}

# indexing a dict
print("mydict['one']", mydict['one'])

# updating a existing key
mydict['two'] = 222222222
print('mydict       ', mydict)
# dictionaries are mutable objects

# Add new key to dict
mydict['six'] = 666666
print('mydict       ', mydict)


new_dict = {'a': 'apple', 'b': 'bat', 'three': 'victory'}

# mydict + new_dict # TypeError: unsupported operand type(s) for +: 'dict' and 'dict'
mydict.update(new_dict)
print('\n after mydict.update(new_dict)')
print(mydict)


# deleting
print('mydict.popitem()', mydict.popitem())
print(mydict)

print("mydict.pop('three', None)", mydict.pop('three', None))
print(mydict)

# del mydict['three']  # KeyError: 'three'
del mydict['two']  # KeyError: 'three'
print(mydict)

mydict.clear()
print(mydict)

del mydict
print(mydict)