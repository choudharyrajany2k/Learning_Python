#!/usr/bin/python
"""
Purpose: Dictionaries
    Properties
        - keys should be unique
"""
from pprint import pprint
mydict_1 = {'Name': 'Python', 'Name': 'Django'}
print(mydict_1)

mydict = {'Name': 'python',
          1232: 7979,
          (1, 2, 4): 'asd',
          True: 'I am a True',
          None: [99999.9898],
          # [1, 2]: {12,3,213}   # TypeError: unhashable type: 'list'
         tuple([1, 2]): {12,3,213},
          'mydict_1': mydict_1,
          1: 'I am one'
          }
# All keys should be immutables only
print(mydict)
pprint(mydict)

