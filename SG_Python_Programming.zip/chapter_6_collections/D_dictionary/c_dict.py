#!/usr/bin/python
"""
Purpose: Dictionaries
"""
my_dict = {1: 2, '3': 4, 5: 7}

print(dict([('banglore', 'Karnataka'), ('chennai', 'Tamil Nadu'), ('hyderabad', 'Telangana')]))
cities = ['banglore', 'chennai', 'hyderabad', 'Pune']
states = ('Karnataka', 'Tamil Nadu', 'Telangana')

print(list(zip(cities, states)))
print(dict(list(zip(cities, states))))
print(dict(list(zip(states, cities))))
print()

# dict is an Iterable object
new_dict = dict(list(zip(states, cities)))
for ech in new_dict:
    print(ech)
# NOTE: when looped, dict will give keys only

print('\n get keys===============')
for ech in new_dict.keys():
    print(ech)


print('\n get values===============')
for ech in new_dict.values():
    print(ech)


print('\n get items===============')
for ech in new_dict.items():
    print(ech)


print('\n get items===============')
for ech_key, ech_val in new_dict.items():
    print(ech_key, '===>', ech_val)
