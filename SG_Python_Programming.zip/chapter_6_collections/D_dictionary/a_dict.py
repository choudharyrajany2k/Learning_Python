#!/usr/bin/python
"""
Purpose: Dictionaries
"""
# empty
empty_dict = {}
print(empty_dict, type(empty_dict))

empty_dict = dict()
print(empty_dict, type(empty_dict))

empty_set = set()
print(empty_set, type(empty_set))

# with one element
one_ele_set = {1}
print(one_ele_set, type(one_ele_set))

one_ele_dict = {1:2}
print(one_ele_dict, type(one_ele_dict))
