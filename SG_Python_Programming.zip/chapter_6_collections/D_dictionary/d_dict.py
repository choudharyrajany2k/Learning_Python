#!/usr/bin/python
"""
Purpose: sorting dictionaries
"""
new_dict = {1: 'c', 2: 'b', 3: 'a'}
print('sorted(new_dict)          ', sorted(new_dict))
print('sorted(new_dict.keys())   ', sorted(new_dict.keys()))
print('sorted(new_dict.values()) ', sorted(new_dict.values()))
print('sorted(new_dict.items())  ', sorted(new_dict.items()))

print()
print('sorted(new_dict.items(), reverse=True) ', sorted(new_dict.items(), reverse=True))

print('\n sorting by key')
print(sorted(new_dict.items(), reverse=True, key=lambda x:x[0]))

print('\n sorting by value')
print(sorted(new_dict.items(), reverse=True, key=lambda x:x[1]))
