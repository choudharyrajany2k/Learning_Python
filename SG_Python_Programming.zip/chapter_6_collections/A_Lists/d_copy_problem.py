#!/usr/bin/python
"""
Purpose: copy problem in lists
"""

mylist  = [11, 22, 33, 44, 55]
hard_copy = mylist  # new object is not created

print(mylist, id(mylist))
print(hard_copy, id(hard_copy))

mylist[2] = 'three'
print('\n after ')
print(mylist, id(mylist))
print(hard_copy, id(hard_copy))

print('\n\nwith copy module')
import copy
soft_copy = copy.copy(mylist)# soft copy or shallow copy
print(mylist, id(mylist))
print(soft_copy, id(soft_copy))

soft_copy[4] = 'five'
print("\n after soft_copy[4] = 'five'")
print(mylist, id(mylist))
print(soft_copy, id(soft_copy))


##########################
myl = [1, 2, 3, 4, [5, 6]]
s_list = copy.copy(myl)
deep_cp_list = copy.deepcopy(myl)

print('myl[4][1]', myl[4][1])
myl[4][1] = 'six'
print('myl[4][1]', myl[4][1])

print()
print(f'myl   :{myl}    id(myl)       :{id(myl)}')
print(f's_list:{s_list}   id(s_list)     :{id(s_list)}')
print(f'deep_cp_list:{deep_cp_list} id(deep_cp_list):{id(deep_cp_list)}')
