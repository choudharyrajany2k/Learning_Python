#!/usr/bin/python
"""
Purpose: List Operations

List Properties:
    - inputted order is retained
    -
"""

# homogenous list
mylist = [1, 2, 4,7, 5 ]
print(mylist, type(mylist))

# Heterogenous list
mylist2 = [1, 3.14, -0.000001, 'asd', True, None, 12+34]
print(mylist2, type(mylist2))


# list is iterable object
for ech_val in mylist2:
    print(ech_val)


print(len(mylist2))
print(f'mylist2 contains {len(mylist2)} elements')


mylist3 = [1, 2, 3, [4, 5, 6]]
# index    0  1  2      3
print(f'mylist3 contains {len(mylist3)} elements')


# Indexing
print('mylist3[2]', mylist3[2])
print('mylist3[3]', mylist3[3])
print('mylist3[3][1]', mylist3[3][1])



mylist4 = [1, [2, [3, 4, (5, 6, [7])]]]
print('mylist4[1][1][2][2][0]', mylist4[1][1][2][2][0])


mylist5 = [11, 22, 33, 44, 55, 66, 777, 88, 999]
# f. index 0    1  2    3   4  5    6    7   8
# r. inex  -9  -8  -7   -6  -5  -4  -3  -2   -1
print('mylist5[1:4]', mylist5[1:4])
print('mylist5[:-3]', mylist5[:-3])  # [11, 22, 33, 44, 55, 66]
print('mylist5[:]', mylist5[:])     # [11, 22, 33, 44, 55, 66, 777, 88, 999]
print('mylist5[::]', mylist5[::])     # [11, 22, 33, 44, 55, 66, 777, 88, 999]
print('mylist5[::-1]', mylist5[::-1])     # [999, 88, 777, 66, 55, 44, 33, 22, 11]
print('mylist5[::-2]', mylist5[::-2])     # [999, 777, 55, 33, 11]


# operator overloading
print('1 + 3 ', 1 + 3)
# print("1 + '1'", 1 + '1')
# NOTE: Python is a strictly typed language

print('[1, 2, 3] + [4, 5, 6]', [1, 2, 3] + [4, 5, 6])

assert [1, 2, 3] + [4, 5, 6] != [4, 5, 6] +  [1, 2, 3]



















