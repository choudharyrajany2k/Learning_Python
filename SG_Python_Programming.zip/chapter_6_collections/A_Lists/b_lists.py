#!/usr/binn/python
"""
Purpose: List Operations
"""
mylist = [1, 2, 3]
print(mylist, type(mylist))

assert mylist.__len__() == len(mylist)
assert mylist.__mul__(3) == mylist * 3
assert mylist.__add__([3]) == mylist + [3]

# List repetition
print('mylist * 3', mylist * 3)
# print('mylist + 3', mylist + 3)
print('mylist + [3]', mylist + [3])


print(dir(mylist))
for ech_attr in dir(mylist):
    if not ech_attr.startswith('__'):
        print(ech_attr)

print('\n\n', mylist)
mylist.append(123)
print('after append(123)        ', mylist)
mylist.append([345])
print('after append([345])      ', mylist)
mylist.append((1, 2, 3))
print('after append((1, 2, 3))  ', mylist)

print('\n\n extend')
# mylist.extend(999)
# TypeError: 'int' object is not iterable
# print('after extend(999)        ', mylist)
mylist.extend([999])
print('after extend(999)        ', mylist)
mylist.extend([1, 3,4])
print('after extend([1, 3,4])   ', mylist)
mylist.extend('122')
print('after extend("121")      ', mylist)


print('\n\n, insert')
mylist.insert(0, 666)
print('after insert(0, 666)     ', mylist)
mylist.insert(3, (2, 3))
print('after insert(3, (2, 3))  ', mylist)
mylist.insert(-1, 33)
print('after insert(-1, 33)     ', mylist)
mylist.insert(56, 44)
print('after insert(56, 44)     ', mylist)


# deleting withut index position
print('mylist.pop()', mylist.pop())
print('mylist.pop()', mylist.pop())
print('mylist.pop()', mylist.pop())
print('mylist.pop()', mylist.pop())
print('mylist.pop()', mylist.pop())
print('after pop                 ', mylist)

# How many times 1 as element at base present
print('mylist.count(1)',mylist.count(1))

# deletes teh first occrenece
print('mylist.remove(1)', mylist.remove(1))
print('after remove(1)', mylist)

# deleting based on indexing
print('mylist[4]            ', mylist[4])
del mylist[4]
print('after del mylist[4]', mylist)

print('mylist[2:5]          ', mylist[2:5])
del mylist[2:5]
print('after del mylist[2:5]', mylist)

mylist.clear()
print('after clear', mylist)
del mylist
print(mylist)






