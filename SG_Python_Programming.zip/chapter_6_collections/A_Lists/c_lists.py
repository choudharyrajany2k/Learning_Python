#!/usr/bin/python
"""
Purpose: list operations
"""
mylist = [22, 66, 88, 4, 7, 22]
print('mylist.index(22)  ', mylist.index(22))
print('mylist.index(22, 2)', mylist.index(22, 2))

# Algorithm for sorting is Timsort
print('sorted(mylist)               ', sorted(mylist))
print('sorted(mylist, reverse=False)', sorted(mylist, reverse=False))
print('sorted(mylist, reverse=True) ', sorted(mylist, reverse=True))

print('mylist                        ', mylist)
mylist.sort()
print('after mylist.sort()           ', mylist)
mylist.sort(reverse=True)
print('after mylist.sort(reverse=True)', mylist)

newlist = [1, 0.1,  True] #,  'a', 'z', 'A', 'Z', None, [12], (12,), {12}, {12:12}]
print('sorted(newlist)', sorted(newlist))
print('max(newlist)   ', max(newlist))
print('min(newlist)   ', min(newlist))

print()
print('max([1, True]) ', max([1, True]))
print('min([1, True]) ', min([1, True]))
print('max([True, 1]) ', max([True, 1]))
print('min([True, 1]) ', min([True, 1]))
# NOTE: whichever is defined first, it will come

# string to list
print('python programming'.split())
print(list('python Programming'))    # ['p', 'y', 't', 'h', 'o', 'n', ' ', 'P', 'r', 'o', 'g', 'r', 'a', 'm', 'm', 'i', 'n', 'g']
print(list((9, 8)))                  # [9, 8]
print(list({2, 3, 4, 6}))            # [2, 3, 4, 6]


# Lists are mutable objects
mylist[4] = 44
print(mylist)
