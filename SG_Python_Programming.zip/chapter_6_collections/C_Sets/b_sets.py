#!/usr/bin/python
"""
Purpose:
To get unique running port numbers from a pool of ports numbers with duplicates,
and displaying them in descending order
"""
running_ports = [ 8080, 443, 443, 8080, 25, 485, 487, 53, 88, 8080, 132, 22, 23]
print(type(running_ports), running_ports)

unique_running_ports =set(running_ports)
print(type(unique_running_ports), unique_running_ports)

unique_ports_in_desc = sorted(unique_running_ports, reverse=True)
print(type(unique_ports_in_desc), unique_ports_in_desc)
