#!/usr/bin/python
"""
Purpose: Frozenset
"""
ord_set = {1, 2, 2, 3}
print(ord_set, type(ord_set))
print(dir(ord_set))

frz_set = frozenset({1, 2, 2, 3})
print(frz_set, type(frz_set))
print(dir(frz_set))


# frz_set.add(9)  # AttributeError: 'frozenset' object has no attribute 'add'

myset = {1, 1.23, -0.00001, None, True, (1, 2, 3), frozenset({1, 2, 3}) }
print(myset)