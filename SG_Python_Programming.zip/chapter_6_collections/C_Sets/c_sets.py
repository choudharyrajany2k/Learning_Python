#!/usr/bin/python
"""
Purpose: Set Operations
"""
myset = set([1, 2, 4])
print(type(myset), myset)

myset = {1, 2, 4}
print(type(myset), myset)

print(dir(myset))

for ech_attr in dir(myset):
    if not ech_attr.startswith('__'):
        print(ech_attr)


# add
myset.add(12)
print('after myset.add(12)', myset)
myset.add(12)
print('after myset.add(12)', myset)
# NOTE: sets are mutable objects

# myset.add([12])      # TypeError: unhashable type: 'list'
# print('after myset.add([12])', myset)

# NOTE: sets cant store mutable objects
# myset.add({12})

myset.add((9, 99))
print('after myset.add((9, 99))', myset)

##########
# update
# myset.update(12)  # TypeError: 'int' object is not iterable
myset.update((12,23))
print('after myset.update((12,23))', myset)

# {1, 2, 4, (9, 99), 12, 23}
myset.remove(4)
print('after myset.remove(4)', myset)

# myset.remove(4)
# print('after myset.remove(4)', myset)   # KeyError: 4

myset.discard(4)
print('after myset.discard(4)', myset)

print('myset.pop()', myset.pop())
print('after pop    ', myset)

print('myset.pop()', myset.pop())
print('after pop    ', myset)

myset.clear()
print('after clear', myset)

# del myset
# print(myset)  # NameError: name 'myset' is not defined
