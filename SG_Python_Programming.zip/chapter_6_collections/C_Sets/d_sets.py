#!/usr/bin/python
"""
Purpose: Set Operations
"""

colors = {'red', 'blue', 'pink', 'gray'}
traffic_signal_colrs = {'yellow', 'green', 'red'}

print(colors.isdisjoint(traffic_signal_colrs)) # False
print('colors.intersection(traffic_signal_colrs)', colors.intersection(traffic_signal_colrs))

print('colors.union(traffic_signal_colrs)       ', colors.union(traffic_signal_colrs))

# differences
print('traffic_signal_colrs  - colors', traffic_signal_colrs  - colors)
print('colors - traffic_signal_colrs  ', colors - traffic_signal_colrs)

print('colors.symmetric_difference(traffic_signal_colrs)', colors.symmetric_difference(traffic_signal_colrs))

print('{1, 2} + {3, 4}', {1, 2} + {3, 4})  # TypeError: unsupported operand type(s) for +: 'set' and 'set'
