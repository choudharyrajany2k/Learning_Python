#!/usr/bin/python
"""
Purpose: sets Operations
    Properties:
        cant store duplicates
        assigned order is not retained
        Doesnt support indexing and slicing
"""
# empty
values = set()  # set
print(f'values:{values} type(values):{type(values)}')

values = {}     # dict
print(f'values:{values} type(values):{type(values)}')

# withone value
values = {1}
print(f'values:{values} type(values):{type(values)}')

values = [1, 2, 2, 3, 2, 4, 3, 5, 4, 5]
print(f'values:{values} type(values):{type(values)}')

values = {1, 2, 2, 3, 2, 4, 3, 5, 4, 5}
print(f'values:{values} type(values):{type(values)}')  # {1, 2, 3, 4, 5}

# values[3]  # TypeError: 'set' object is not subscriptable

for ech_val in values:
    print(ech_val)
# NOTE: Set is an iterable object

print(f'len(values):{len(values)}')