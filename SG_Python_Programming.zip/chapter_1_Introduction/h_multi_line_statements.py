#!/usr/bin/python
"""
Purpose: Multi-line statements

\  - line continuation operator

()
[]
{}
"""

sum_of_values = 123 - 324 + 3242 // 324 + 23   \
                + 123 - 324 + 3242 / 324 + 23  \
                - 123 - 324 + 3242 // 324 + 23  \
                * 123 - 324 + 3242 // 324 + 23  \
                / 123 - 324 + 3242 // 324 + 23

# NOTE: nothing, not even comments can be written after \

print('sum_of_values', sum_of_values) # result is display in console


sum_of_values = (123 - 324 + 3242 // 324 + 23 
                + 123 - 324 + 3242 / 324 + 23 
                - 123 - 324 + 3242 // 324 + 23  
                * 123 - 324 + 3242 // 324 + 23  
                / 123 - 324 + 3242 // 324 + 23)
print('sum_of_values', sum_of_values) # result is display in console


sum_of_values = [123 - 324 + 3242 // 324 + 23 
                + 123 - 324 + 3242 / 324 + 23 
                - 123 - 324 + 3242 // 324 + 23  
                * 123 - 324 + 3242 // 324 + 23  
                / 123 - 324 + 3242 // 324 + 23]
print('sum_of_values', sum_of_values) # result is display in console




sum_of_values = {123 - 324 + 3242 // 324 + 23 
                + 123 - 324 + 3242 / 324 + 23 
                - 123 - 324 + 3242 // 324 + 23  
                * 123 - 324 + 3242 // 324 + 23  
                / 123 - 324 + 3242 // 324 + 23}
print('sum_of_values', sum_of_values) # result is display in console





