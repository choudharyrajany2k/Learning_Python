print('hello world')

print("Python")


print(2132)