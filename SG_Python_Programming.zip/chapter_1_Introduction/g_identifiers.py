#!/usr/bin/python
"""
Purpose: keywords and Identifiers

variable, keyword, Identifiers
"""

# NOTE: Dont use keywords or alike words, as identifiers
# True = 21312
# true = 123123


# Rules for creating identifiers
# identifier - user-defined variable
# 1. first character : a-z, A-Z, _
# 1. other characters: a-z, A-Z, _, 0-9

name = 'Python'
Name = 'Python'
_name = 'Python'
__name = 'Python'

name123 = 'Python'
name_123 = 'Python'


# name_123$ = 'Python'
# 2name = 'Python'
# first name = 'python'
# first-name = 'python'
first_name = 'python'


# python is case-sensitive
animal = 'cat'
Animal = 'DOG'

# print(ANIMAL)
# NameError: name 'ANIMAL' is not defined


# variable casing 
#  underscore casing (or) snake casing
rating = 2
no_of_sensors_processed = 23
cost_of_mango = 12
cost_of_apples_in_dozens = 56

# camel casing 
rating = 2
noOfSensorsProcessed = 23
costOfMango = 12
costOfApplesInDozens = 56

# PEP 8 recommends to use underscore casing 
# for all identifiers, including fuction names also
# Only for class names, use camelCasing





































