#!/usr/bin/python
"""
Purpose: importance of comments

NOTE: Python is interpreter based language
NO multi-line comment in python
"""
num1 = 123
num2 = 345

print(num1)
print('num1', num1)
print('num2', num2)

# num3 = num1 + num2 
# print('num3=', num3)
