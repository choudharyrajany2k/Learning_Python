#!/usr/bin/python
"""
Purpose: TO prove that 
Python is a dynamic typed language
"""

num1 = 123
# print(num1)
print('num1      =', num1)
print('type(num1)=', type(num1))
print()

num1 = 123.324
print('num1      =', num1)
print('type(num1)=', type(num1))
print()

num1 = 324234324234324234342342343434
print('num1      =', num1)
print('type(num1)=', type(num1))
print()
# ? what is the largest num that can be processed in python

num1 = 0.000000213102123123
print('num1      =', num1)
print('type(num1)=', type(num1))
print()

num1 = None
print('num1      =', num1)
print('type(num1)=', type(num1))
print()

num1 = 'None'
print('num1      =', num1)
print('type(num1)=', type(num1))
print()

num1 = True
print('num1      =', num1)
print('type(num1)=', type(num1))
print()



