#!/usr/bin/python
"""
Purpose: Importance of Indentation
"""
__name__ = 'Python Tutor'



#  print('Hello world')    
# IndentationError: unexpected indent
print('Hello world') 

# block of code -if , else, while, for , def , class

# if 12 > 3:
# print('greater')
# # IndentationError: expected an indented block

if 12 > 3:
    print('greater')

num1 = 123
num2 = 345
if num1 == num2:
    print('both are equal')
elif num1 > num2:
    print('num1 > num2')
else:
    print('num2  > num1')

for ech_val in (1, 2, 3, 4, 5):
    print(ech_val)

def myfunc():
    print("IN myfunc")

myfunc()


class MyClass:
    pass

m = MyClass()

##########################
if 12 > 3:
    if 12 > 5:
        if 12 > 1:
            if 12 > 4:
                num34 = 2213
                print('It is greatest')
            else:
                print('something')

# PEP 8 - recommends spaces to tabs -> 4 white spaces






