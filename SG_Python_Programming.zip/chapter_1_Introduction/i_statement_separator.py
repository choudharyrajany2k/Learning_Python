#!/usr/bin/python
"""
Purpose:

; statement separator
"""

num1 = 123
num2 = 4543

num3 = num1 + num2 
print('num3 =', num3)

#################################
num1 = 123; num2 = 4543; num3 = num1 + num2; print('num3 =', num3)

# python -c "num1 = 123; num2 = 4543; num3 = num1 + num2; print('num3 =', num3)"
