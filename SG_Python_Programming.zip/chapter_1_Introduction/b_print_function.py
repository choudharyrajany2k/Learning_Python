#!/usr/bin/python
"""
Purpose: shebang line & print importance
"""
# shebang line 

# print as statement in python 2.x
# print 'Hello world'

# print as a function in python 3.x
print('Hello world')

print('one')
print('two')

print('one', end='\n')
print('two')


print('one', end='__')
print('two')

print('hello', 'python')
print('hello', 'python', sep=' ')
print('hello', 'python', sep='||')

print()
print('one', 'two', sep='||', end='__')
print('three')

















