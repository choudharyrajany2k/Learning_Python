import logging

# Fixing the level of severity
logging.basicConfig(level=logging.INFO)

logging.debug("This is a debug2")
logging.info("This is a info2")
logging.warning("This is a warning2")
logging.error("This is a error2")
logging.critical("This is a critical2")
