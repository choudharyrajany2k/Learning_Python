import urllib.request, urllib.parse, urllib.error
import re
htmlfile = urllib.openurl("http://finance.yahoo.com/q?s=AAPL")