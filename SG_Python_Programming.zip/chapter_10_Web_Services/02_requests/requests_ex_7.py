import requests
from pprint import pprint 

URL = 'https://indian-cities-api-nocbegfhqg.now.sh/cities' #?State=Karnataka&District=Dakshina%20Kannada
response = requests.get(URL, params={
    'State':'Karnataka', 'District':'Dakshina Kannada'
})
print('response.status_code', response.status_code)
print('response.url', response.url)
print(response.headers['Content-Type'])
if response.status_code == 200:
    json_response = response.json()
    # pprint(json_response)
    print(f'{len(json_response)} records were retrieved')

    for each_record in json_response:
        #if each_record.get('State')== 'Karnataka':
        #if each_record.get('District')== 'Dakshina Kannada':
        print(each_record.get('City'))

