import requests
from pprint import pprint 

URL='https://randomuser.me/api/'
response = requests.get(URL)
json_object = response.json()

pprint(json_object)

print('On page {page_no}, i found {title}{first_name}{last_name}')
