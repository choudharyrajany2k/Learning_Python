import requests
from pprint import pprint 

URL='https://yesno.wtf/api/'
response = requests.get(URL)
# print(response)
# print(type(response.text), response.text) # raw 
pprint(response.json())

json_string = response.json()  
answer = json_string.get('answer')

print(f'answer:{answer}')