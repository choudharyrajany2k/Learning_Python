import requests

URL='https://randomuser.me/'
response = requests.get(URL)
print(response)
# print(response.text)
  

with open('randomuser.html', 'w') as f:
    f.write(response.text)
    f.close()