import requests

URL='https://www.google.com/search?tbm=isch&sa=1&ei=zi_SXKD6OZuUwgOOhadA&q=RESTful+service&oq=RESTful+service&gs_l=img.3..0l2j0i8i30l8.58100.64720..65144...2.0..0.182.1485.0j10......0....1..gws-wiz-img.......0i67.jzSbHAzh_o8'
response = requests.get(URL)
print(response)
# print(response.text)


# HTML
# CSS 
# javscript 
#     jquery
#     angular 
#     react  

with open('result.html', 'w') as f:
    f.write(response.text)
    f.close()