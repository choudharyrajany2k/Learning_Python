import requests
from pprint import pprint 

URL = 'https://httpstatusdogs.com/img/201.jpg'

# response =requests.get(URL)
# print(response.status_code)
# # print(response.text)
# pprint(response.headers['Content-Type'])

# with open('image.jpg', 'wb') as f:
#     f.write(response.content)
#     f.close()


for code in range(99, 600, 1):
    URL = f'https://httpstatusdogs.com/img/{code}.jpg'
    response = requests.get(URL)
    if response.headers['Content-Type'] == 'image/jpeg':
        print(URL, response.status_code)
        with open(f'{code}.jpg', 'wb') as f:
            f.write(response.content)
            f.close()
