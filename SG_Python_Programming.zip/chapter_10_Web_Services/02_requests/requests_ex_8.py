import requests
from pprint import pprint 

URL = 'https://httpstatusdogs.com/img/201.jpg'

response =requests.get(URL)
print(response.status_code)
# print(response.text)
pprint(response.headers['Content-Type'])

with open('image.jpg', 'wb') as f:
    f.write(response.content)
    f.close()