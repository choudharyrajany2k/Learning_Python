import requests
from pprint import pprint 

URL = 'https://api.darksky.net/forecast/31c39a286280e612d422506ad76cc2db/17.4828617,78.3271216'
res = requests.get(URL)
print(res.status_code)

# pprint(res.json())

with open('weather_forecast.json', 'w') as f:
    f.write(res.text)
    f.close()