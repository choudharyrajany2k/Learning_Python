import requests

URL='https://yesno.wtf/'
response = requests.get(URL)
print(response)
# print(response.text)


# HTML
# CSS 
# javscript 
#     jquery
#     angular 
#     react  

with open('yesno.html', 'w') as f:
    f.write(response.text)
    f.close()