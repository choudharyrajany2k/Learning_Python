import requests
from requests_oauthlib import OAuth1
from configparser import ConfigParser

parser = ConfigParser()
parser.read('twitter_credentails.ini')

APP_KEY = parser.get('TWITTER_TEST_APP', 'APP_KEY')
APP_SECRET = parser.get('TWITTER_TEST_APP', 'APP_SECRET')
USER_OAUTH_TOKEN = parser.get('TWITTER_TEST_APP', 'USER_OAUTH_TOKEN')
USER_OAUTH_TOKEN_SECRET = parser.get('TWITTER_TEST_APP', 'USER_OAUTH_TOKEN_SECRET')

url = 'https://api.twitter.com/1.1/account/verify_credentials.json'
auth = OAuth1(APP_KEY, APP_SECRET,
              USER_OAUTH_TOKEN, USER_OAUTH_TOKEN_SECRET)

response = requests.get(url, auth=auth)
# print(response)

from pprint import pprint
# pprint(response.json())


url = 'https://api.twitter.com/1.1/search/tweets.json?q=nasa&result_type=popular'
response = requests.get(url, auth=auth)
pprint(response.json())
