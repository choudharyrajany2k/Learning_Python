#!/usr/bin/python
"""
Purpose: Usage of quotes for strings definition
"""

language = 'Python Programming'
print(language, type(language))
print()

language = "Python Programming"
print(language, type(language))
print()

language = '''Python Programming'''
print(language, type(language))
print()

language = """Python Programming"""
print(language, type(language))
print()

# multi-line strings
print('one \
two \
three')

print("one \
two \
three")

print('''one \
two \
three''')

print("""one \
two \
three""")

print('''one 
two 
three''')

print("""one 
two 
three""")