#!/usr/bin/python
"""
Purpose: ceaser cipher implementation
"""

word = 'bag'


