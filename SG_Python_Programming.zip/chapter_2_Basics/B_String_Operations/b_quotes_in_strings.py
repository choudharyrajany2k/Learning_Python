#!/usr/bin/python
"""
Purpose: Handling quotes in strings
"""
mystring = 'Python progamming'
print(mystring)

mystring = '!@#^^&^%&^*&(*)(_)_)+_'
print(mystring)

# mystring = 'what's next'
mystring = 'what\'s next'
print(mystring)


mystring = 'sadasd\'s asdasd\'asd asdas\'asdas'
print(mystring)

mystring = "sadasd's asdasd'asd asdas'asdas"
print(mystring)

print('\'')
print("'")
print('"')

print('"sdfdsf"')

# 'asdasd'  "asdasds"
# print(''asdasd'  "asdasds"')
# print("'asdasd'  "asdasds"")

print(''' 'asdasd'  "asdasds" ''')












