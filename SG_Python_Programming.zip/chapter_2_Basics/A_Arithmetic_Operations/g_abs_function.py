#!/usr/bin/python
"""
purpose:  abs() function
"""

print('abs(-9)', abs(-9))
print('abs(9) ', abs(9))

# complex
print(abs(3 + 4j))
print((3 ** 2  + 4 ** 2)  ** (1/2))

print()
print(abs(-3 + 4j))
print(((-3) ** 2  + 4 ** 2)  ** (1/2))