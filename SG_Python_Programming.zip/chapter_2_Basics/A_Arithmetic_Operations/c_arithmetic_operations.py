#!/usr/bin/python
"""
Purpose: Arithemetic operations
"""

print('pow(2, 3)', pow(2, 3))
print('pow(4, 2)', pow(4, 2))

print('pow(64, 1/2)', pow(64, 1/2))
print('pow(64, 0.5)', pow(64, 0.5))

print('pow(4, 2, 10)', pow(4, 2, 10))
# pow(4, 2) % 10
print('pow(2, 3, 7)', pow(2, 3, 7))

print()
print('2 ** 3', 2 ** 3)
print('4 ** 2', 4 ** 2)
print('4 ** 2 % 10', 4 ** 2 % 10)

print()
print('pow(64, 1/2)', pow(64, 1/2))
print('64 ** 1/2  ) ', 64 ** 1/2)
print('(64 ** 1)/2 )', (64 ** 1)/2)
print('64 **( 1/2) )', 64 ** (1/2))






