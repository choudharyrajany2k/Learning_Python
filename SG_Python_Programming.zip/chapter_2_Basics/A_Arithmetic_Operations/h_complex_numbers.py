#!/usr/bin/python
"""
Purpose: complex numbers
= real + imaginary no
"""
num1= 10
print(num1, type(num1))
print()

num1= 10 + 1j
print(num1, type(num1))

num1= 10 + 0j
print(num1, type(num1))

# print(dir(num1))

print('num1.real     ', num1.real)
print('num1.imag     ', num1.imag)
print('num1.conjugate', num1.conjugate)
print('num1.conjugate()', num1.conjugate())
