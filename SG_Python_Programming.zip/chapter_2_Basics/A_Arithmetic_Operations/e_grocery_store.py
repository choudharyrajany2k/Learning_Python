#!/usr/bin/python
"""
Purpose: Grocery Store App
"""

cost_of_rice = 53 # per kg
cost_of_wheat = 34 # per kg 

qty_of_rice = 20 # kgs 
qty_of_wheat = 90  # kgs 

sp_of_rice = cost_of_rice * qty_of_rice
sp_of_wheat = cost_of_wheat * qty_of_wheat

total_cost = sp_of_rice + sp_of_wheat
print('total_cost', total_cost)

# 10 % discount on bill
after_discount = total_cost - total_cost * 0.10
print('after_discount', after_discount)

# GST - 12.5 % 
after_gst = after_discount + after_discount * 0.125
print('after_gst', after_gst)






