#!/usr/bin/python
"""
Purpose: Compound operations
"""
num1 = 100

# i++, i --, --i, ++i - unary operators

num1 = num1 + 1
print('num1', num1)

num1 += 1
print('num1', num1)

num1 -= 3           # num1 = num1 - 3
print('num1', num1)

num1 *= 3           # num1 = num1 * 3
print('num1', num1)

num1 /= 3           # num1 = num1 / 3
print('num1', num1)

num1 //= 3           # num1 = num1 // 3
print('num1', num1)

num1 %= 3           # num1 = num1 % 3
print('num1', num1)



