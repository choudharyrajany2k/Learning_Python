#!/usr/bin/python
"""
Purpose: Arithmetic Operations
"""
num1 = 123
num2 = 324

num3 = num1 + num2 
print('num3=', num3)

print()

print('10 + 3 =',10 + 3)
print('10 - 3 =',10 - 3)
print('10 * 3 =',10 * 3)
print()

print('10 / 2 =',10 / 2)
print('10 / 5 =',10 / 5)
print('10 / 3 =',10 / 3)
#  result of division will be float only 

'''
    3) 10 ( 3  --> quotient
        9
    -------
        1   ----> remainder

'''
# // floor division
print()
print('10 / 3 =',10 / 3)
print('10 //3 =',10 // 3)
print('10 % 3 =',10 % 3)

print()
print('10 / 2 =',10 / 2)
print('10 //2 =',10 // 2)
print('10 % 2 =',10 % 2)

print()
print('divmod(10, 3)', divmod(10, 3))
print('divmod(10, 2)', divmod(10, 2))
















