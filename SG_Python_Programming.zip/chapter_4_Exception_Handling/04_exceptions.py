#!/usr/bin/python
"""
Purpose: raising  exceptions
"""
try:
    # raise NameError('name is not correct')
    raise Exception('name is not correct')
except (NameError,TypeError) as ex:
    print('name/type error is', repr(ex))
except ZeroDivisionError as ex:
    print('zero div error is', repr(ex))
except Exception as ex:
    print('umbrella div error is', repr(ex))
