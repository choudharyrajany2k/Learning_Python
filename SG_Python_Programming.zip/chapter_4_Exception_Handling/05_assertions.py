#!/usr/bin/python
"""
Purpose: assertions
"""

assert 1 == 1, 'not equal'

try:
    assert 1 != 1, 'not equal'
except AssertionError as ex:
    print(repr(ex))

assert 12 + 23/45 + 3 - 6 == 9.511, 'wrong'