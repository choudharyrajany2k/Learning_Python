#!/usr/bin/python
"""
Purpose: Handling multiple exceptions
"""
try:
    a = 1/0 + b + 23 +  '1' + 1
except NameError as ex:
    print('name error is', repr(ex))
except ZeroDivisionError as ex:
    print('zero div error is', repr(ex))
except TypeError as ex:
    print('type error is', repr(ex))
except Exception as ex:
    print('umbrella div error is', repr(ex))
