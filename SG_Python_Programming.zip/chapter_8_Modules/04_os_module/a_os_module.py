#!/usr/bin/python
"""
Purpose: OS module
"""

import os
print(os)

print(dir(os))

print('The current working directory is ', os.getcwd())

# list files - window(dir), linu(ls)
# list files in current working directory
print('os.listdir()', os.listdir())


print('files in C:\Python27\Scripts are')
print(os.listdir('C:\Python27\Scripts'))


print('c:\one\newfolder')
print('c:\\one\\newfolder')
print(r'c:\one\newfolder')
print('c:/one/newfolder')

# changing directory - cd
os.chdir(r'C:\Python27\Scripts')
print('The current working directory is ', os.getcwd())




