#!/usr/bin/python
"""
Purpose: Script to get all the files in a directory and its sub-directories , of a
particular extension
"""
import os

# print(f'os.getcwd():{os.getcwd()}')
#
# print("os.listdir(r'C:\Python27')", os.listdir(r'C:\Python27'))
#
# print(os.walk(r'C:\Python27'))
#
# for ech in os.walk(r'C:\Python27'):
#     # ('C:\\Python27', ['etc', 'include', 'Lib', 'Scripts', 'share', 'UDHAY_A'], ['README.rst'])
#     print(ech)
#     break
#
# python_files = []
# for ech_dir, ech_dirs, ech_files in os.walk(r'C:\Python27'):
#     # print(ech_files)
#     for ech_file in ech_files:
#         file_extn = os.path.splitext(ech_file)[1]
#         if file_extn == '.py':
#             python_files.append(ech_file)
#
# print(f'There are {len(python_files)} python files under the directory ', r'C:\Python27')


# TO get the size of any file: os.stat('conclusions.txt').st_size

# function definition
def get_files_of_particular_extn(extension_name, path_file=os.getcwd()):
    """
    To get the files of a particular extension within the directory and subdirectories
    :param extension_name: extension name such as .py, .png, .jpg, ...
    :param path_file: relative or absolute directory path
    :return: list of matched files
    """
    extn_files = []
    for present_path, folders, files in os.walk(path_file):
        for each_file in files:
            file_extn = os.path.splitext(each_file)[1]
            if file_extn == extension_name:
                extn_files.append(each_file)
    return extn_files


print('__name__', __name__)

if __name__ == '__main__':
    # function call
    extension_specific_files = get_files_of_particular_extn('.py')
    print("extension_specific_files:")
    for file_name in extension_specific_files:
        print(file_name)

    print('total files count', len(extension_specific_files))
    print("os.getcwd():", os.getcwd())
    print('-' * 20)

    custom_path = r'C:\Users\udhayPrakash\Desktop\PythonMaterial\A_Basic'
    extension_specific_files = get_files_of_particular_extn('.py', custom_path)
    print("extension_specific_files:")
    for file_name in extension_specific_files:
        print(file_name)

    print('total files count', len(extension_specific_files))
else:
    print("imported")
