#!/usr/bin/python
"""
Purpose: OS Module
"""

import os
print('os.getcwd()', os.getcwd())

print("os.listdir()         ", os.listdir())
print("os.listdir('.')      ", os.listdir('.'))
print("os.listdir(os.curdir)", os.listdir(os.curdir))

print('os.curdir', os.curdir)

# for ech_file in os.listdir(os.curdir):
#     print(ech_file)


print("os.path.exists('SOCGEN')", os.path.exists('SOCGEN'))

# os.remove('SOCGEN')
if not os.path.exists('SOCGEN'):
    os.mkdir('SOCGEN')
print()
for ech_file in os.listdir(os.curdir):
    print(ech_file)

# changing directory
os.chdir('SOCGEN')
print('os.getcwd()', os.getcwd())

my_path = '/'.join(['ram', 'robert', 'rahim'])
print(f'my_path = {my_path}')


print(f'os.sep: {os.sep}') # windows - \ ; linux - /

my_path = (os.sep).join(['ram', 'robert', 'rahim'])
print(f'my_path = {my_path}')

print(f'os.path.exists(my_path):{os.path.exists(my_path)}')
if not os.path.exists(my_path):
    os.makedirs(my_path)