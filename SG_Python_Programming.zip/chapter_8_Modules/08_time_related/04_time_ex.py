import time

print(help(time))
print('starting ')
time.sleep(12)
print('after sleeping')