import subprocess
import os

command_to_execute = 'ping google.com'
result = os.system(command_to_execute)
print(type(result), result)


p = subprocess.Popen(command_to_execute,
                     stdout=subprocess.PIPE,
                     stderr=subprocess.PIPE)
out, err = p.communicate()
print(f'''
    out: {out.decode('utf-8')}
    err: {err.decode('utf-8')}
''')

print('-' * 20 )

out = out.decode('utf-8')
last_line =  out.splitlines()[-1]
print(last_line)
print(last_line.split(' '))
average_ping_druation = last_line.split(' ')[-1]
print(f'average_ping_druation:{average_ping_druation}')