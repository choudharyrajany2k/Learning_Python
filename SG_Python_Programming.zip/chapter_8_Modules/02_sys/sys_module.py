#!/usr/bin/python
import sys

print('sys.path', type(sys.path))

for each_path in sys.path:
    print(each_path)

# user_input = sys.stdin.readline('Enter something:')
# print("Input : " + user_input)
