#!/usr/bin/python
"""
Purpose: Importance of sys.argv
"""
print('__file__', __file__)
import sys

print('sys.argv', sys.argv)

if len(sys.argv) < 2:
    print('please enter the ticket number')
    sys.exit(0)

winning_ticket = 'asd123asdw34-3242'

# user_ticket = input('Enter your ticket number:')
user_ticket = sys.argv[1]

if user_ticket == winning_ticket:
    print('Congratulatons! you won the lotter. ')
else:
    print('Else TRY your luck again !!!')