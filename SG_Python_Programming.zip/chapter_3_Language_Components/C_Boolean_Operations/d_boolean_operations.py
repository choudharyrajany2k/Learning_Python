#!/usr/bin/python
"""
Purpose: bool() function usage 
"""

if 12 < 34:
    print('12< 34')

# backend implemenation
if bool(12 < 34):
    print('12< 34')

if not 12 < 34:
    print('12< 34')

# backend implemenation
if bool(not 12 < 34):
    print('12< 34')


name = ''
if name:
    print('It is not empty ')

if bool(name):
    print('It is not empty ')
    
if name != '':
    print('It is not empty ')



if 1:
    print(' I will come always')


if 324.234324234:
    print(' I will come always')

if not 0:
    print(' I will come always')


