#!/usr/bin/python
"""
Purpose: Boolean Operations

True False
"""

print('str(True) == str(1)', str(True) == str(1))
print('str(True)', str(True))
print('str(1)   ', str(1))


print('str(True * 3) == str(1 * 3)', str(True * 3) == str(1 * 3))
#NOTE: In arithemtic operations, True will give a value of 1 
# and False will give a value of 0

