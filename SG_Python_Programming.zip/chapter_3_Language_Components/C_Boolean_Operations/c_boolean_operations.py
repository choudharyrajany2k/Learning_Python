#!/usr/bin/python
"""
Purpose: Boolean Operations

True False

bool()

Integers 
    int, -ve int , zero 
    float, -float , zero 

String 
    empty string, string with some chars

None

bool
    True False

braces 
    empty braces 
    braces with content 
"""
print('bool(98798798)', bool(98798798))
print('bool(-32434)  ', bool(-32434))
print('bool(-0)      ', bool(-0))
print()

print('bool(3.14)    ', bool(3.14))
print('bool(-0.0000001)', bool(-0.02))
print('bool(0.0)      ', bool(0.0))
print()
#NOTE: non-zero => True 
#      zero     => False


print("bool('python')", bool('python'))
print("bool(' ')     ", bool(' '))
print("bool('')      ", bool(''))
print()
# NOTE: non-empty string => True
#       empty string     => False

# Braces - (), [], {}
print('bool([12])    ', bool([12]))
print('bool((12))    ', bool((12)))
print('bool({12})    ', bool({12}))

print('bool([])      ', bool([]))
print('bool(())      ', bool(()))
print('bool({})      ', bool({}))
print()
# NOTE: braces with content => True
#       empty braces        => False


# None
print('bool(None)    ', bool(None))

# bool- True & False
print('bool(True)    ', bool(True))
print('bool(False)   ', bool(False))



