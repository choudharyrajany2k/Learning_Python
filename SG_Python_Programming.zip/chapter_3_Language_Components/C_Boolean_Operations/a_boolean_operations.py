#!/usr/bin/python
"""
Purpose: Boolean Operations

True False
"""

val = True
print(val, type(val))

val = False
print(val, type(val))

# val = false
# print(val, type(val))

'''
object
    - address where it is stored    id()
    - value(s)                      print()
    - data type of value(s)         type()
'''
print()
print('id(val)  ', id(val))
print('val      ', val)
print('type(val)', type(val))


# NOTE: True has a value  of 1 
print('True * 8   ', True * 8)
print('True * 0.04', True * 0.04)

# NOTE: False has a value  of 0 
print('False * 8   ', False * 8)
print('False * 0.04', False * 0.04)










