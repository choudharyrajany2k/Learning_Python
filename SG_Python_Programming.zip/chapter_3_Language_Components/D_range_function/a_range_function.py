#!/usr/bin/python
"""
Purpose: range()

range(start_value, end_value, step)
default 
    step = +1
    start_value = 0

NOT DEFAULT END_VALUE
"""
numbers = range(9)
print(numbers, type(numbers))
print(list(numbers))
print()

numbers = range(0, 9)
print(numbers, type(numbers))
print(list(numbers))
print()

numbers = range(0, 9, 1)
print(numbers, type(numbers))
print(list(numbers))
print()


numbers = range(4, 9, 1)
print(numbers, type(numbers))
print(list(numbers))
print()

numbers = range(4, 9, 2)
print(numbers, type(numbers))
print(list(numbers))
print()

numbers = range(99, 45, 2)
print(numbers, type(numbers))
print(list(numbers))
print()

numbers = range(99, 45, -2)
print(numbers, type(numbers))
print(list(numbers))
print()