#!/usr/bin/python
"""
Purpose: Palindrome numbers

121 <=> 121

"""

for i in range(1000):
    if str(i) == str(i)[::-1]:
        print(i, end=' ')
    # print(str(i) == str(i)[::-1]) #, type(str(i)))