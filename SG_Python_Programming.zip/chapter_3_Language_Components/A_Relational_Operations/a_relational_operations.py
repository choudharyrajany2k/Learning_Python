#!/usr/bin/python
"""
Purpose: Relational OPerations
"""

print('12 < 34', 12 < 34)
print('12 > 34', 12 > 34)
print('12 >= 34', 12 >= 34)
print('12 <= 34', 12 <= 34)
print('12 == 34', 12 == 34)

usd = 76
cad = 56

print('usd > cad', usd > cad)