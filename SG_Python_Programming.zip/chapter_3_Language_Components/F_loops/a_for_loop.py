#!/usr/bin/python
"""
Purpose: for loop
"""

# for(i=0; i<78; i++)

# for i in 1:
#     print(i)
# TypeError: 'int' object is not iterable

# for i in 12.3323:
#     print(i)
#     TypeError: 'float' object is not iterable

# Non-iterable objects: int, float, None, bool(True/False)
# Iterable Objects: string, list, tuple, set, dict, iterator, generator

for ech_chr in 'Python':
    print(ech_chr)

print()
for loop_indx, ech_chr in enumerate('Python'):
    print(loop_indx, '==>', ech_chr)

print()
for loop_indx, ech_chr in enumerate('Python', 43):
    print(loop_indx, '==>', ech_chr)

for ech_val in [1, 2, 3, 4, 5]:
    print(ech_val)

for ech_val in (1, 2, 3, 4, 5):
    print(ech_val)

for ech_val in {1, 2, 3, 4, 5}:
    print(ech_val)

for ech_val in range(8):
    print(ech_val)



