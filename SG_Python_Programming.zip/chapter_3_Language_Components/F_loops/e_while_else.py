#!/usr/bin/python
"""
Purpose: while -else

"""

i = 0
while i < 10:
    i +=1
    print(i)
else:
    print('All loops executed\n')

print('##### break #################')
i = 0
while i < 10:
    i +=1
    if i == 5:
        break
    print(i)
else:
    print('All loops executed')

print('##### continue #################')
i = 0
while i < 10:
    i +=1
    if i == 5:
        continue
    print(i)
else:
    print('All loops executed')


print('##### pass #################')
i = 0
while i < 10:
    i +=1
    if i == 5:
        pass
    print(i)
else:
    print('All loops executed')

import sys
print('##### sys.exit #################')
i = 0
while i < 10:
    i +=1
    if i == 5:
        sys.exit(0)
    print(i)
else:
    print('All loops executed')

print('next Statemenst')