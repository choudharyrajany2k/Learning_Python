#!/usr/bin/python
"""
Purpose: Number Guessing Game with limited chances
"""
LUCKY_NUMBER = 67
TOTAL_CHANCES = 5

# # Unlimited chances
# while 1:
#     guessing_number = int(input('Guess no. btwn 0 & 100:'))
#     if guessing_number == LUCKY_NUMBER:
#         print('COngrats! You guessed correctly')
#         break
#     elif guessing_number > LUCKY_NUMBER:
#         print('Lower your guess')
#     else:
#         print('Increase your guess')



# Limited chances
chance_no= 1
while chance_no <= TOTAL_CHANCES:
    print(f'\nchance_no:{chance_no}')
    guessing_number = int(input('Guess no. btwn 0 & 100:'))
    if guessing_number == LUCKY_NUMBER:
        print('COngrats! You guessed correctly')
        break
    elif guessing_number > LUCKY_NUMBER:
        print('Lower your guess')
    else:
        print('Increase your guess')
    chance_no += 1
else:
    print('YOu are depleted of chances')

print('Next statement')




