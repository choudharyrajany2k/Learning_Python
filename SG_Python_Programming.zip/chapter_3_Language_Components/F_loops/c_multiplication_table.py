#!/usr/bin/python
"""
Purpose: Multiplication Table
"""

i = 1
while i <= 10:
    j = 0
    while j <= 10:
        # print(i , '*', j, '=', i *j )           
        # print('%2d * %2d = %3d'%(i, j, i*j))        # old style formatting
        # print('{:2} * {:2} = {:3}'.format(i, j, i *j))# new style formatting
        print(f'{i:2} * {j:2} = {i*j:3}')              # f-strings
        j += 1
    print('-' * 12)
    i += 1