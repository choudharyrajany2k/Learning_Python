#!/usr/bin/python

for i in range(10):
    print('*' * i )

for i in range(10, 0, -1):
    print('*' * i)


###################

i = 0
while i <= 10:
    print('*' * i )
    i += 1

# print(f'i={i}')
i = 10
while i> 0:
    print('*' * i )
    i -=1  

######################
for i in range(10):
    print(' '*(10 -i),  '*' * i )

for i in range(10, 0, -1):
    print(' '*(10 -i),  '*' * i )
