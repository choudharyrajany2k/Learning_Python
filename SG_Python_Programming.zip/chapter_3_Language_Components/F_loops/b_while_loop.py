#!/usr/bin/python
"""
Purpose: while loop

syntax
------
initialization
while condition:
    logic 
    increment/decrement
"""

# Incrementing loop
i = 0
while i < 10:
    i += 1
    print(i)

# Decrementing loop
j = 10 
while j > 0:
    print(j)
    j -= 1