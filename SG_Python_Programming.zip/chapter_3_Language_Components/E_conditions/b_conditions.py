#!/usr/bin/python
"""
Purpose: Employee login-logout Time table

MON- FRI : 9.00 AM to 6 PM 
SAT      : 9.00 AM to 1 PM
SUN      : HOLIDAY
"""

week_of_day = input('Enter week of day:').lower().strip()
print('you entered', week_of_day)


if week_of_day == 'monday':
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'tuesday':
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'wednesday':
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'thursday':
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'friday':
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'saturday':
    print('TIMINGS: 9.00 AM to 1.00 PM')
elif week_of_day == 'sunday':
    print('TIMINGS: HOLIDAY ')
else:
    print('Invalid entry', week_of_day)



if (week_of_day == 'monday'
    or week_of_day == 'tuesday'
    or week_of_day == 'wednesday'
    or week_of_day == 'thursday'
    or week_of_day == 'friday'):
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'saturday':
    print('TIMINGS: 9.00 AM to 1.00 PM')
elif week_of_day == 'sunday':
    print('TIMINGS: HOLIDAY ')
else:
    print('Invalid entry', week_of_day)


# in - membership check operator 
if week_of_day in  ['monday', 'tuesday','wednesday','thursday','friday']:
    print('TIMINGS: 9.00 AM to 6.00 PM')
elif week_of_day == 'saturday':
    print('TIMINGS: 9.00 AM to 1.00 PM')
elif week_of_day == 'sunday':
    print('TIMINGS: HOLIDAY ')
else:
    print('Invalid entry', week_of_day)


'''
>>> 1 in [1, 2, 3]
True
>>> 11 not in [1, 2, 3]
True
>>>
>>> 'd' in 'python'
False
>>> "y" in 'python'
True
>>> 1 in 1111
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: argument of type 'int' is not iterable
>>>
'''