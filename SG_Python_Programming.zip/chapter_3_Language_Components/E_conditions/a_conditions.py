#!/usr/bin/python
"""
Purpose: Number Guessing Game
"""
LUCKY_NUMBER = 67

guessing_number = int(input('Guess a number btwn 0 & 100:'))

# if guessing_number == LUCKY_NUMBER:
#     print('COngrats! You guessed correctly')

# if guessing_number == LUCKY_NUMBER:
#     print('COngrats! You guessed correctly')
# else:
#     print('Please Try again!!!')


if guessing_number == LUCKY_NUMBER:
    print('COngrats! You guessed correctly')
elif guessing_number > LUCKY_NUMBER:
    print('Lower your guess')
else:
    print('Increase your guess')


    