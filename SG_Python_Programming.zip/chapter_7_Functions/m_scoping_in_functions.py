#!/usr/bin/python
"""
Purpose: Scoping in functions

L _ Local
E _ enclosing
G - Global
B - builtin
"""
# immutable objects
pi = 3.1416

# CASE 1 : Using without passing args
# def my_func():
#     print(f'pi    = {pi}')
#     print(f'pi *3 = {pi * 3}')

# CASE 2: using and modifying object without passing arg
# def my_func():
#     print(f'before pi  = {pi}')
#     pi = 33333
#     print(f'after pi  = {pi}')

# UnboundLocalError: local variable 'pi' referenced before assignment
#
# def my_func(pi):
#     print(f'before pi  = {pi}')
#     pi = 33333
#     print(f'after pi   = {pi}')
#
# my_func(pi)
# print(f'outside pi = {pi}')
# NOTE: changes with in function were nt reflected
#    outside the function  - CALL BY VALUE

# CASE : to reflect changes within function to outside(globally)
#       --- CALL BY REFERENCE

def my_func():
    global pi
    print(f'before pi  = {pi}')
    pi = 33333
    print(f'after pi   = {pi}')

my_func()
print(f'outside pi = {pi}')


# CONCLUSION : For immutable objects,
#     default ---> CALL BY VALUE
#     with global -> CALL BY REFERENCE

print()
# Mutable objects
python = {
    'ver' : '3.7.6'
}

def my_func():
    print(f"before python['ver']:{python['ver']}")
    python['ver'] = 123123
    print(f"after python['ver']:{python['ver']}")


my_func()
print(f"outside python['ver']:{python['ver']}")


'''
Mutable ___> CALL BY REFERENCE BY DEFAULT 
'''
