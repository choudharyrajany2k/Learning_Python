#!/usr/bin/python
"""
Purpose: Infinite Recursions
"""
import sys
print(f'sys.getrecursionlimit():{sys.getrecursionlimit()}')

sys.setrecursionlimit(2000)
print(f'sys.getrecursionlimit():{sys.getrecursionlimit()}')

num = 0
def myfunc():
    global num
    print('I am in loop', num)
    print('In myfunc')
    num += 1
    return myfunc()

myfunc()