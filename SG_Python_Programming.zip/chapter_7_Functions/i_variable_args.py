#!/usr/bin/python
"""
Purpose: Variable args function
or variadic function
"""
def my_func(mand, *values, df_val=0):
    print('\nmandaatory arg value', mand)
    print('df_val arg value    ', df_val)
    print(f'values:{values}')
    print(f'type(values):{type(values)}')

my_func('a')
my_func(123)
my_func(123, 34, '234')
my_func(123, 34, '234', 234, 234, 234, 23)
my_func(123, 34, '234', 234, 234, 234, 23, df_val=999)