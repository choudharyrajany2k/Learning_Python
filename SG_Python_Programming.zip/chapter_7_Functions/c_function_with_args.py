#!/usr/bin/python
"""
Purpose: Function with args
"""


def addition(n1, n2):
    result = n1 + n2
    print(result)


addition(1, 2)  # 3
addition(-3, 2)  # -1

######################
def multiplication(p1, p2):
    result = p1 * p2
    print(result)


multiplication(1, 2)
multiplication(-3, 2)
