#!/usr/bin/python
"""
Purpose:
    Importanace of Functions
        - To handle coe redundancy
        - breaking complex problem into small parts
"""


# Function Definition
def my_func():
    print('Hello')


# Function call
my_func()
my_func()
my_func()
