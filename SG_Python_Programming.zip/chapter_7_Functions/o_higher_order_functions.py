#!/usr/bin/python
"""
Purpose: Higher Order Functions
"""


# def even_test(num):
#     if num % 2 == 0:
#         return 'even'
#     else:
#         return 'odd'

def even_test(num):
    return 'even' if num % 2 == 0 else 'odd'


evnt = lambda num: ('even' if num % 2 == 0 else 'odd')
print('even_test(222)', even_test(222))
print('evnt(222)      ', evnt(222))


#############################
new_list = []
for i in range(100):
    new_list.append(even_test(i))
print(new_list)

###############
print()
def double(num):
    return num * 2


double_list = []
for i in range(100):
    double_list.append(double(i))
print(double_list)

double_list = []
for i in range(100):
    double_list.append( (lambda x: x * 2)(i))
print(double_list)


print(map(lambda x: x * 2, range(100)))
print(list(map(lambda x: x * 2, range(100))))


print(list(map(lambda x: x % 2==0, range(100))))

# To get only even numbers
print(list(filter(lambda x: x % 2==0, range(100))))

# To get only odd numbers
print(list(filter(lambda x: x % 2!=0, range(100))))


print()
from functools import reduce
print(reduce(lambda x,y: x +y, (1, 2, 3, 4)))

# factorial(5)
print(reduce(lambda x,y: x *y, range(1, 5+1)))

# print(list(map(lambda x,y: x* y, range(1, 5+1))))
print(list(map(lambda x,y: x* y, range(1, 5+1),  range(1, 5+1))))




