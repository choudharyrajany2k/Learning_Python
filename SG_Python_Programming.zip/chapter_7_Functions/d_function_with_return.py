#!/usr/bin/python
"""
Purpose: Function with return value(s)
"""


def hello():
    print('Hwllo world')
    # return None
    # return True
    # return 123123
    # return 123123.32
    # return 123123.32,
    # return 123123.32,, SyntaxError: invalid syntax
    # return (123123.32,),
    # return 12, 231
    # return (12, 231)
    # return [12, 231]
    # return set([12, 231])
    # return 'hello world'
    return 12 + 213 /2131

# NOTE: default function result is None
# NOTE: return is last statement eexcutable in function


# print('hello()', hello())
result = hello()
print(type(result), result)
