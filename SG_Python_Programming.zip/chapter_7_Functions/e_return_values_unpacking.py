#!/usr/bin/python
"""
Purpose: return values unpacking
"""

######### unpacking
num1 = 123
num2 = 345

num1,num2 = 123, 345
print(num1,num2 )

n1, n2, n3, n4, n5 = 55, 44, 33, 22, 11
print(n1, n2, n3, n4, n5)

# n1, n2, n3, n4 = 55, 44, 33, 22, 11
# ValueError: too many values to unpack (expected 4)

# n1, n2, n3, n4, n5 = 55, 44, 33, 22
# ValueError: not enough values to unpack (expected 5, got 4)

n1 = (55, 44, 33, 22, 11)


# list unpacking 
v1, v2 = [34, 45]


###############################

def my_func():
    return 123, 345


result = my_func()
print(type(result), result)

r1, r2 = my_func()
print(f'r1 = {r1} \n r2={r2}')