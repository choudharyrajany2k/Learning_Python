#!/usr/bin/python
"""
Purpose: Function Overwriting

a = 123
a = 456
print(a) # 456
"""

def addition(var1, var2, var3):
    return var1 + var2 + var3


def addition(num1, num2):
    return num1 + num2



print(addition(12, 34, 56))  # 102
print(addition(12, 34))  # 46
