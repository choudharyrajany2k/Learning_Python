#!/usr/bin/python
"""
Purpose: Recursion Functions

syntax:
    def function(<ARGS>):
        logic of termination
        return function(<ARGS>)
"""


# fact(5) = 5 * 4 * 3 * 2 * 1

def factorial(num):
    if num == 1:
        return 1
    print(f'num:{num}')
    return num * factorial(num - 1)


print('factorial(5)', factorial(5))
'''
factorial(5) =  5 * factorial(4)
                    4 * factorial(3)
                        3 * factorial(2)
                            2 * factorial(1)

'''
