#!/usr/bin/python
"""
Purpose: default and mandaatory args together
"""


# NOTE: defaalt args should be at the last only
def addition(var1, var2=0, var3=0):
    return var1 + var2 + var3


print(addition(11, 22, 33))
print(addition(11, 22))
print(addition(11))
print(addition())  # TypeError: addition() missing 1 required positional argument: 'var1'

