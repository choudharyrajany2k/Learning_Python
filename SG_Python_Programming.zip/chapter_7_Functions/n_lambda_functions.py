#!/usr/bin/python
"""
Purpose:  Lambda Functions
"""

def double(x):
    """
    This is  function to return the double of a given nnumber
    :param x:
    :return:
    """
    return x * 2

print(double(3)) # 6
#
# # Functions are first class objects in python
# print(type(double))
# print(dir(double))
# help(double)

print(  (lambda x: x* 2)(3)   )
dbl = lambda x: x* 2
print( dbl(3) )


#########################
def addition(n1, n2):
    return n1 + n2

print(addition(11, 22))
print((lambda n1,n2: n1 + n2)(11, 22))


bin_expr = lambda p : p ** 2 + 2 * p ** 3 + 9
print(bin_expr(9))













