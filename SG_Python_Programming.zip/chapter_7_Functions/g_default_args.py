#!/usr/bin/python
"""
Purpose: Function with default args
"""


#
# def addition(num1, num2):
#     return num1 + num2


def addition(var1, var2, var3=0):
    return var1 + var2 + var3


print(addition(12, 34, 56))  # 102
print(addition(12, 34))  # 46


#####################
def hello(name='world'):
    print('hello ' + name)


hello()
hello('python')
