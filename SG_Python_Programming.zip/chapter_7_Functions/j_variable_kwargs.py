#!/usr/bin/python
"""
Purpose: Variable keyword args
"""

# def hello(name):
#     return 'hello' + name
#
#
# print(hello('Python'))
# print(hello(name='Python'))
# # print(hello(name1='Python'))

def hello(**kw_args):
    print(f'kw_args      :{kw_args}')
    print(f'type(kw_args):{type(kw_args)}')


hello()
# hello(1232) # TypeError: hello() takes 0 positional arguments but 1 was given
hello(name='Python')
hello(name='Python', age=77)
hello(name='Python', age=77, location='India')


##########################

def combination(mand, *args, **kwargs):
    print(f'\n mand:{mand}, {type(mand)}')
    print(f'   args:{args}, {type(args)}')
    print(f' kwargs:{kwargs}, {type(kwargs)}')


# combination() # TypeError: combination() missing 1 required positional argument: 'mand'
combination(11)
combination(11, 22)
combination(11, 22, 33)
combination(11, 22, 33, name='Gudo')










