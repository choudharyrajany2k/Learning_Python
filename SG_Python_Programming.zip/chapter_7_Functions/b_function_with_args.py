#!/usr/bin/python
"""
Purpose: Function with args
"""


# Function Definition
def hello(name):
    print('Hello '+ name)

# hello()  # TypeError: hello() missing 1 required positional argument: 'name'
hello('Gudo Van Russum')
# hello('Gudo Van Russum', 23)  # TypeError: hello() takes 1 positional argument but 2 were given

hello(name='Gudo Van Russum')
# hello(name1='Gudo Van Russum')  # TypeError: hello() got an unexpected keyword argument 'name1'
