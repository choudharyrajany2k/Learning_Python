#!/usr/bin/python
"""
Purpose: Debugging 
two 
    - console based debugging - pdb
    - IDE based debuggging    - pydevd

"""
# import pdb;pdb.set_trace()
# breakpoint()

for i in range(9):
    if i % 2 == 0: 
        print(i)


