#!/usr/bin/python
"""
Purpose: Debugging with pydevd
Display all odd prime numbers between 0 & 1000
1, 3, 5, 7, 9, 11, 13, 15, 17 ...
1, 3, 5, 7,    11, 13,     17
"""
for num in range(0, 500):
    if num % 2 != 0:
        for i in range(1, num):
            if num % i == 0 and i != 1:
                # print(f'{num} is not a prime number')
                break
            # print(i, num % i == 0)
        else:
            print(f'{num} is prime number')


# num = 18
# for i in range(1, num):
#     if num % i == 0 and i != 1:
#         print('It is not a prime number')
#         break
#     print(i, num % i == 0)
