

def fun(x):
    return x + 1

if __name__ == '__main__':
    print(fun(33))