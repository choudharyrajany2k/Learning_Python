
        00001
            12   00002
        _Value|address of next node___   


        00002
 00002      13  00003
        _Value|address of next node___   

        00003
            67  0004
        _Value|address of next node___   

        0004   00001
        _Value|address of next node___   
