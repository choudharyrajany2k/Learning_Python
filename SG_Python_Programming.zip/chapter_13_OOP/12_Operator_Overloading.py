# Operator overloading
# # ,(comma) 
# print('hello', 'world', end=' ')
# print('udhay')

# Arithmetic  Addition
print(12 + 34)  
print(12.0 + 34)
print(12.0 + 234234234234234)
print((3 + 3j) + (4 + 7j))

print('12' + '34')  # string concatenation

print([12, 24, 35] + [23, 34])
# print (99, 45) + [33, 999]
print((99, 45) + tuple([33, 999]))

# print {12, 34, 5} + {2, 5}  # sets doesn't suppport
# print {'a': 1} + {'c':4}    # dicts doesn't support